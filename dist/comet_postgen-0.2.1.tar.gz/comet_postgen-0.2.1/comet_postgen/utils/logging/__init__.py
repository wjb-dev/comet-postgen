from .log_util import get_label

__all__ = ["get_label"]